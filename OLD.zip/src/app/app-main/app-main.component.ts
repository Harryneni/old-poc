import { Component, OnInit } from "@angular/core";
import { environment } from "src/environments/environment";

@Component({
    selector: 'app-main',
    templateUrl: './app-main.component.html',
    styleUrls: ['./app-main.component.scss']
  })
export class AppMainComponent implements OnInit {

    mainLabel: String = environment.LABELS.MAIN;

    constructor() { }
  
    ngOnInit(): void {

    }
  
    
  }
  
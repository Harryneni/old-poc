import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: 'app-user',
  templateUrl: './app-user.component.html',
  styleUrls: ['./app-user.component.scss']
})
export class AppUserComponent implements OnInit {

  public Nav = [
    { linkName: 'link 1', routerLink: '/user/data' },
    { linkName: 'link 2', routerLink: '/user/old-data' },
    { linkName: 'link 3', routerLink: '/user/new-data' },
  ]

  constructor(public router: Router) { }

  ngOnInit(): void {

  }

}
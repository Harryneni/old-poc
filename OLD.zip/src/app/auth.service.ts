import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedin = false;
  users = [
    {
      userName: 'JDoe', fullName: 'John Doe'
    }, {
      userName: 'RDoe', fullName: 'Rohn Doe'
    }, {
      userName: 'HDoe', fullName: 'Hohn Doe'
    }, {
      userName: 'KDoe', fullName: 'Kohn Doe'
    }, {
      userName: 'NDoe', fullName: 'Nohn Doe'
    }, {
      userName: 'MDoe', fullName: 'Mohn Doe'
    }, {
      userName: 'ODoe', fullName: 'Oohn Doe'
    },
  ];

  fullName: string;

  constructor() { }

  isAuthenticated() {
    const promise = new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(this.isLoggedin);
        console.warn(this.isLoggedin);
      }, 800)
    })

    return promise;
  }

  isLogin(userName: string) {
    this.isLoggedin = true;

    this.users.map((user) => {
      if (user.userName.toLowerCase() === userName.toLowerCase()) {
        this.fullName = user.fullName;
      }
    });
  }

  isLogout() {
    this.isLoggedin = false;
  }
}

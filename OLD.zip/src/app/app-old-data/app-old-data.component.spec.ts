import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppOldDataComponent } from './app-old-data.component';

describe('AppOldDataComponent', () => {
  let component: AppOldDataComponent;
  let fixture: ComponentFixture<AppOldDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppOldDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppOldDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppNewDataComponent } from './app-new-data.component';

describe('AppNewDataComponent', () => {
  let component: AppNewDataComponent;
  let fixture: ComponentFixture<AppNewDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppNewDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppNewDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

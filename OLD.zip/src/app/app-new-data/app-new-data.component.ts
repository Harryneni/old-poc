import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-new-data',
  templateUrl: './app-new-data.component.html',
  styleUrls: ['./app-new-data.component.css']
})
export class AppNewDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

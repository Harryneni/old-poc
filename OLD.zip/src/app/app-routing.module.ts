import { Component, NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AppDataComponent } from "./app-data/app-data.component";
import { AppHomeComponent } from "./app-main/app-home.component";
import { AppUserComponent } from "./app-main/app-user.component";
import { AppNewDataComponent } from "./app-new-data/app-new-data.component";
import { AppOldDataComponent } from "./app-old-data/app-old-data.component";
import { AuthGuardService } from "./auth-guard.service";
import { LoginComponent } from "./login/login.component";
import { PagenotfoundComponent } from "./pagenotfound/pagenotfound.component";


const routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'home', component: AppHomeComponent, canActivate: [AuthGuardService] },
    {
        path: 'user', component: AppUserComponent, canActivate: [AuthGuardService], children: [
            { path: 'data', component: AppDataComponent },
            { path: 'old-data', component: AppOldDataComponent },
            { path: 'new-data', component: AppNewDataComponent },
            { path: '**', component: AppDataComponent },
        ]
    },
    { path: 'not-found', component: PagenotfoundComponent },
    { path: '**', redirectTo: '/not-found' },
];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {



}
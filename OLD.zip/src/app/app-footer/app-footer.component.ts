import { Component, Input, OnInit } from '@angular/core';
import { HeaderNavigationLink } from 'uswds';
import { TableDataSource, UsaHeaderPrimaryLink, UsaNavigationLink } from '@gsa-sam/ngx-uswds';

@Component({
  selector: 'app-footer',
  templateUrl: './app-footer.component.html',
  styleUrls: ['./app-footer.component.scss']
})
export class AppFooterComponent implements OnInit {

  @Input()
  showFooter: boolean;

  columnHeaders = ['variable', 'description'];
  dataRows: TableDataSource = [
    {
      variable: '$theme-header-font-family ',
      description: 'Font family of the header.',
    },
    {
      variable: '$theme-header-logo-text-width',
      description: 'Width of the logo text area at desktop width as a percentage of the total header width.'
    },
    {
      variable: '$theme-header-max-width',
      description: 'Maximum width of the header.'
    },
    {
      variable: '$theme-header-min-width',
      description: 'Breakpoint at which the non-mobile header is shown.'
    },
  ]
  constructor() { }

  ngOnInit(): void {
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;

  constructor(public authService: AuthService, public router: Router, private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      userName: ['JDoe', Validators.required],
      password: ['passw0rd', Validators.required],
      checked: [true, Validators.required]
    });
  }

  onSubmit() {
    this.authService.isLogin(this.loginForm.get('userName').value);
    if (this.authService.isLoggedin) {
      this.router.navigate(['/home']);
    }
  }

  onClick() {
    window.open('https://portal.osha.gov/dte/rulesofbehaviourservlet', 'blank');
  }
}

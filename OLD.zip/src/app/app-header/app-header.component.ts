import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsaNavigationMode, UsaHeaderPrimaryLink, UsaNavigationLink } from '@gsa-sam/ngx-uswds';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.scss']
})
export class AppHeaderComponent implements OnInit {
  showDropdown = false;
  showSearchDropdown = false;

  selectedValue: string;

  foods: any[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'},
  ];

  @Input()
  showHeader: boolean;

  constructor(public authService: AuthService, public router: Router,) {
    this.showHeader = false;
   }

  ngOnInit(): void {
  }

  secondaryLinks: UsaNavigationLink[] = [
    {
      text: 'User : John Doe',
      id: 'request',
      selected: true,
      href: '/header/examples'
    },
    {
      text: 'Logout',
      id: 'messages',
    },
  ];

  primaryLinks: UsaHeaderPrimaryLink[] = [
    {
      text: 'Home',
      id: 'home',
      mode: UsaNavigationMode.INTERNAL,
      // Including children link in data model adds them in as submenu
      children: [
        {
          text: 'Main',
          id: 'homeChild1',
          mode: UsaNavigationMode.INTERNAL,
          path: 'home'
        },
        {
          text: 'User',
          id: 'homeChild2',
          mode: UsaNavigationMode.INTERNAL,
          path: 'user'
        },
        {
          text: 'Item 3',
          id: 'homeChild3',
          href: '/header/examples',
        }
      ],
    },
    {
      text: 'Search',
      id: 'search',
      isMegamenu: false, // Defining megamenu with children will display the submenu as a megamenu
      children: [
        {
          text: 'Item 1',
          id: 'homeChild1',  
          href: '/header/examples',
        },
        {
          text: 'Item 2',
          id: 'homeChild2',
          href: '/header/examples',
        },
        {
          text: 'Item 3',
          id: 'homeChild3',
          href: '/header/examples',
        },
      ],
    },
  ]

  logLinkEvent($event) {
    console.log('Link Event Extended Header', $event);
  }

  onClickHandler() {
    this.showDropdown = !this.showDropdown;
    this.showSearchDropdown = false;
    this.showHeader = true;
  }

  onClickSearchHandler() {
    this.showSearchDropdown = !this.showSearchDropdown;
    this.showDropdown = false;
    this.showHeader = true;
  }

  onLogoutHandler() {
    this.authService.isLogout();
  }

}

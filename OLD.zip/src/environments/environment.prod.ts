export const environment = {
  production: true,
  LABELS : {
    HEADER: 'Header Content!',
    FOOTER: 'Footer Content!',
    MAIN: 'Main Content!'
  }
};

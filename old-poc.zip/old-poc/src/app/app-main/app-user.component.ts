import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'app-user',
    templateUrl: './app-user.component.html',
    styleUrls: ['./app-user.component.scss']
  })
export class AppUserComponent implements OnInit {


    constructor() { }
  
    ngOnInit(): void {

    }
  
    
  }
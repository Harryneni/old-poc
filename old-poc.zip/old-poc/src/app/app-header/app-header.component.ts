import { Component, OnInit } from '@angular/core';
import { UsaNavigationMode, UsaHeaderPrimaryLink, UsaNavigationLink } from '@gsa-sam/ngx-uswds';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.scss']
})
export class AppHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  secondaryLinks: UsaNavigationLink[] = [
    {
      text: 'User : John Doe',
      id: 'request',
      selected: true,
      href: '/header/examples'
    },
    {
      text: 'Logout',
      id: 'messages',
    },
  ];

  primaryLinks: UsaHeaderPrimaryLink[] = [
    {
      text: 'Home',
      id: 'home',
      mode: UsaNavigationMode.INTERNAL,
      // Including children link in data model adds them in as submenu
      children: [
        {
          text: 'Main',
          id: 'homeChild1',
          mode: UsaNavigationMode.INTERNAL,
          path: 'home'
        },
        {
          text: 'User',
          id: 'homeChild2',
          mode: UsaNavigationMode.INTERNAL,
          path: 'user'
        },
        {
          text: 'Item 3',
          id: 'homeChild3',
          href: '/header/examples',
        }
      ],
    },
    {
      text: 'Search',
      id: 'search',
      isMegamenu: false, // Defining megamenu with children will display the submenu as a megamenu
      children: [
        {
          text: 'Item 1',
          id: 'homeChild1',  
          href: '/header/examples',
        },
        {
          text: 'Item 2',
          id: 'homeChild2',
          href: '/header/examples',
        },
        {
          text: 'Item 3',
          id: 'homeChild3',
          href: '/header/examples',
        },
      ],
    },
  ]

  logLinkEvent($event) {
    console.log('Link Event Extended Header', $event);
  }

}

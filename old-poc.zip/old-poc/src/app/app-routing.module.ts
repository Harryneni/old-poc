import { Component, NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AppHomeComponent } from "./app-main/app-home.component";
import { AppUserComponent } from "./app-main/app-user.component";

const routes = [ 
    {path: 'home', component: AppHomeComponent},
{path: 'user', component: AppUserComponent},
{path: '**', component: AppHomeComponent}];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {
    
   

}
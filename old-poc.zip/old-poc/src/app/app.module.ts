import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { AppHeaderComponent } from './app-header/app-header.component';
import { AppFooterComponent } from './app-footer/app-footer.component';
import { AppMainComponent } from './app-main/app-main.component';
import { AppHomeComponent } from './app-main/app-home.component';
import { AppUserComponent } from './app-main/app-user.component';
import { AppRoutingModule } from './app-routing.module';
import { UsaHeaderModule, UsaTableModule, USWDSCardFooterComponent } from '@gsa-sam/ngx-uswds';

@NgModule({
  declarations: [
    AppComponent,
    AppHeaderComponent,
    AppFooterComponent,
    AppMainComponent,
    AppHomeComponent,
    AppUserComponent
  ],
  imports: [
    BrowserModule,
    UsaHeaderModule,
    UsaTableModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
